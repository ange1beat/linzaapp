import { createClient } from 'redis';
import { config } from '../config';

const redisClient = createClient({
  // url: 'redis://localhost:6379'
  url: `redis://${config.redis_username}:${config.redis_password}@${config.redis_host}:${config.redis_port}`,
  socket: { tls: true }
});

redisClient.on('error', (err) => {
  console.error('Redis Client Error', err);
});

redisClient.on('connect', () => {
  console.log('Redis Client Connected');
});

redisClient.connect();

export default redisClient;
