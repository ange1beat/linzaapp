#!/bin/bash

echo "🧹 Manually cleaning up OpenBug demo..."

# Kill main tmux session (services + menu)
tmux kill-session -t openbug 2>/dev/null && echo "✓ Killed tmux session"

# Kill OpenBug server session
tmux kill-session -t openbug-server 2>/dev/null && echo "✓ Killed OpenBug server"

# Kill OpenBug Studio session
tmux kill-session -t openbug-studio 2>/dev/null && echo "✓ Killed OpenBug Studio"

# Fallback: kill anything on demo ports
lsof -ti:3001 -ti:3002 -ti:4173 | xargs kill 2>/dev/null

echo "✅ Manual cleanup complete"
